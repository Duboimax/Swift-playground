import UIKit


func generateNumber() -> [Int] {
    var array: [Int] = []
    for _ in 1...20 {
        array.append(Int.random(in: 1..<100))
    }
    return array
}

func sum(list array: [Int]) -> Int {
    return array.reduce(0, +)
}

func avg(list array: [Int]) -> Int {
    var result: Int = sum(list: array)
    result = result / array.count
    return result
}

func filterPair(list array: [Int]) -> [Int]{
    return array.filter{ element in
        element % 2 == 0
    }
}

func intToString(list array: [Int]) -> [String] {
    return array.map { String($0)}
}


var arrayInt = generateNumber()


print(arrayInt)
print(sum(list: arrayInt))

print(avg(list: arrayInt))

print(arrayInt.max() ?? 0)

print(filterPair(list: arrayInt))

print(intToString(list: arrayInt))
